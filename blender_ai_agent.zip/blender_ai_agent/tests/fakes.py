"""
fakes.py
========
Hinglish: SceneInspector, Object/Material/Modifier/Camera/GeometryNodes/
Animation Tools ko test karne ke liye "Fake" BlenderBridge.
"""


class FakeModifier:
    """bpy Modifier jaisa dikhne waala fake modifier."""

    def __init__(self, name, type_):
        self.name = name
        self.type = type_
        self.width = None
        self.levels = None
        self.thickness = None
        self.node_group = None


class FakeModifierCollection:
    """obj.modifiers jaisa dikhne waala fake collection."""

    def __init__(self):
        self._modifiers = []

    def new(self, name, type):
        modifier = FakeModifier(name=name, type_=type)
        self._modifiers.append(modifier)
        return modifier

    def get(self, name):
        for mod in self._modifiers:
            if mod.name == name:
                return mod
        return None

    def remove(self, modifier):
        self._modifiers.remove(modifier)


class FakeObject:
    """bpy Object jaisa dikhne waala fake object."""

    def __init__(self, name, type_="MESH", location=None, rotation=None, scale=None,
                 non_manifold_edge_count=0, flipped_normal_count=0, bounding_box_size=1.0,
                 face_count=6, tri_count=0, pole_count=8):
        self.name = name
        self.type = type_
        self.location = location or [0.0, 0.0, 0.0]
        self.rotation_euler = rotation or [0.0, 0.0, 0.0]
        self.scale = scale or [1.0, 1.0, 1.0]
        self.material_name = None
        self.modifiers = FakeModifierCollection()
        self.keyframes = []  # list of (frame, location) tuples — Step 9.13

        # QA stats — Step 12.7
        self.non_manifold_edge_count = non_manifold_edge_count
        self.flipped_normal_count = flipped_normal_count
        self.bounding_box_size = bounding_box_size

        # Topology stats — retopology
        self.face_count = face_count
        self.tri_count = tri_count
        self.pole_count = pole_count
        self.hidden = False

class FakeMaterial:
    """bpy Material jaisa dikhne waala fake material."""

    def __init__(self, name, color=None, roughness=0.5, metallic=0.0):
        self.name = name
        self.color = color or [0.8, 0.8, 0.8, 1.0]
        self.roughness = roughness
        self.metallic = metallic
        self.emission_color = [0.0, 0.0, 0.0, 1.0]
        self.emission_strength = 0.0


class FakeBridge:
    """BlenderBridge jaisa interface, lekin bpy ke bina."""

    def __init__(self, scene_name="TestScene", objects=None, materials=None):
        self._scene_name = scene_name
        self._objects = objects or []
        self._materials = materials or []
        self._active_camera = None
        self._last_render_path = None
        self.world = {"world": "World", "color": [0.05, 0.05, 0.05], "strength": 1.0}

    # ---------------------------------------------------------
    # Scene / objects
    # ---------------------------------------------------------
    def get_scene_name(self):
        return self._scene_name

    def get_objects(self):
        return self._objects

    def get_object(self, name):
        for obj in self._objects:
            if obj.name == name:
                return obj
        return None

    def create_object(self, name, object_type="MESH", primitive="CUBE", location=None):
        obj = FakeObject(name=name, type_=object_type, location=location or [0.0, 0.0, 0.0])
        self._objects.append(obj)
        return obj

    def delete_object(self, name):
        obj = self.get_object(name)
        if obj is None:
            return False
        self._objects.remove(obj)
        return True

    def set_object_visibility(self, object_name, hide):
        obj = self.get_object(object_name)
        if obj is None:
            return False
        obj.hide_viewport = hide
        obj.hide_render = hide
        return True

    def list_blend_objects(self, filepath):
        # Hinglish: Fake mein hum simulate karte hain ki file mein
        # 3 fixed objects hain - real Blender mein ye asli .blend
        # file padh kar aata hai.
        return ["fake_blend_obj_a", "fake_blend_obj_b", "fake_blend_obj_c"]

    def import_blend(self, filepath, object_names=None, name_prefix=None):
        available = self.list_blend_objects(filepath)
        names = available if object_names is None else object_names
        missing = [n for n in names if n not in available]
        if missing:
            raise ValueError(f"Object(s) {missing} not found in '{filepath}'. Available: {available}")
        imported = []
        for n in names:
            final_name = f"{name_prefix}{n}" if name_prefix else n
            obj = FakeObject(name=final_name, type_="MESH", location=[0.0, 0.0, 0.0])
            self._objects.append(obj)
            imported.append(obj)
        return imported

    def import_model(self, filepath, name=None, scale=None):
        import os
        base = os.path.splitext(os.path.basename(filepath))[0]
        obj = FakeObject(name=(name or base), type_="MESH", location=[0.0, 0.0, 0.0])
        if scale is not None:
            obj.scale = list(scale)
        self._objects.append(obj)
        return [obj]

    def duplicate_object(self, name, new_name=None):
        obj = self.get_object(name)
        if obj is None:
            return None

        final_name = new_name or f"{obj.name}.001"
        new_obj = FakeObject(
            name=final_name,
            type_=obj.type,
            location=list(obj.location),
            rotation=list(obj.rotation_euler),
            scale=list(obj.scale),
        )
        self._objects.append(new_obj)
        return new_obj

    def rename_object(self, old_name, new_name):
        obj = self.get_object(old_name)
        if obj is None:
            return None
        obj.name = new_name
        return obj

    def transform_object(self, name, location=None, rotation=None, scale=None):
        obj = self.get_object(name)
        if obj is None:
            return None

        if location is not None:
            obj.location = location
        if rotation is not None:
            obj.rotation_euler = rotation
        if scale is not None:
            obj.scale = scale

        return obj

    # ---------------------------------------------------------
    # Materials — Step 2.5
    # ---------------------------------------------------------
    def get_material(self, name):
        for mat in self._materials:
            if mat.name == name:
                return mat
        return None

    def create_material(self, name, color=None):
        material = FakeMaterial(name=name, color=(list(color) + [1.0]) if color and len(color) == 3 else color)
        self._materials.append(material)
        return material

    def assign_material(self, object_name, material_name):
        obj = self.get_object(object_name)
        material = self.get_material(material_name)

        if obj is None or material is None:
            return False

        obj.material_name = material.name
        return True

    def modify_material(self, name, color=None, roughness=None, metallic=None,
                        emission_color=None, emission_strength=None):
        material = self.get_material(name)
        if material is None:
            return None

        if emission_color is not None:
            material.emission_color = (list(emission_color) + [1.0]) if len(emission_color) == 3 else list(emission_color)
        if emission_strength is not None:
            material.emission_strength = emission_strength

        if color is not None:
            material.color = (list(color) + [1.0]) if len(color) == 3 else list(color)
        if roughness is not None:
            material.roughness = roughness
        if metallic is not None:
            material.metallic = metallic

        return material

    # ---------------------------------------------------------
    # Modifiers — Step 2.6
    # ---------------------------------------------------------
    def add_modifier(self, object_name, modifier_name, modifier_type="BEVEL"):
        obj = self.get_object(object_name)
        if obj is None:
            return None
        return obj.modifiers.new(name=modifier_name, type=modifier_type)

    def remove_modifier(self, object_name, modifier_name):
        obj = self.get_object(object_name)
        if obj is None:
            return False

        modifier = obj.modifiers.get(modifier_name)
        if modifier is None:
            return False

        obj.modifiers.remove(modifier)
        return True

    def configure_modifier(self, object_name, modifier_name, properties):
        obj = self.get_object(object_name)
        if obj is None:
            return None

        modifier = obj.modifiers.get(modifier_name)
        if modifier is None:
            return None

        for key, value in properties.items():
            if hasattr(modifier, key):
                setattr(modifier, key, value)

        return modifier

    # ---------------------------------------------------------
    # Camera / Render — Step 2.7
    # ---------------------------------------------------------
    def create_camera(self, name, location=None, rotation=None):
        camera_obj = FakeObject(
            name=name,
            type_="CAMERA",
            location=location or [0.0, 0.0, 0.0],
            rotation=rotation or [0.0, 0.0, 0.0],
        )
        self._objects.append(camera_obj)
        return camera_obj

    def set_active_camera(self, name):
        obj = self.get_object(name)
        if obj is None or obj.type != "CAMERA":
            return False
        self._active_camera = obj
        return True

    def render_preview(self, filepath):
        # Real file save nahi karte tests mein — bas path record karte hain
        self._last_render_path = filepath
        return filepath

    # ---------------------------------------------------------
    # Geometry Nodes — Step 9.8
    # ---------------------------------------------------------
    def add_geometry_nodes(self, object_name, node_group_name):
        obj = self.get_object(object_name)
        if obj is None:
            return None
        return obj.modifiers.new(name=node_group_name, type="NODES")

    def get_geometry_nodes(self, object_name, modifier_name):
        obj = self.get_object(object_name)
        if obj is None:
            return None
        return obj.modifiers.get(modifier_name)
    # ---------------------------------------------------------
    # Geometry QA — Step 12.7
    # ---------------------------------------------------------
    def get_mesh_stats(self, object_name):
        obj = self.get_object(object_name)
        if obj is None or obj.type != "MESH":
            return None

        half = obj.bounding_box_size / 2.0
        cx, cy, cz = obj.location

        return {
            "vertex_count": 8,
            "non_manifold_edge_count": obj.non_manifold_edge_count,
            "flipped_normal_count": obj.flipped_normal_count,
            "bounding_box_min": [cx - half, cy - half, cz - half],
            "bounding_box_max": [cx + half, cy + half, cz + half],
        }

    def recalculate_normals(self, object_name):
        obj = self.get_object(object_name)
        if obj is None or obj.type != "MESH":
            return False
        obj.flipped_normal_count = 0
        return True

    # ---------------------------------------------------------
    # Retopology
    # ---------------------------------------------------------
    @staticmethod
    def _fake_topology(obj):
        faces = obj.face_count
        tris = obj.tri_count
        quads = faces - tris
        return {
            "vertex_count": faces + 2,
            "face_count": faces,
            "tri_count": tris,
            "quad_count": quads,
            "ngon_count": 0,
            "quad_ratio": (quads / faces) if faces else 0.0,
            "pole_count": obj.pole_count,
        }

    def get_topology_stats(self, object_name):
        obj = self.get_object(object_name)
        if obj is None or obj.type != "MESH":
            return None
        return self._fake_topology(obj)

    def retopologize(self, object_name, method="QUADRIFLOW", target_faces=2000,
                     voxel_size=0.05, decimate_ratio=0.5, preserve_sharp=True,
                     smooth_normals=True, new_name="", hide_original=True):
        src = self.get_object(object_name)
        if src is None or src.type != "MESH":
            return None

        before = self._fake_topology(src)

        if method == "QUADRIFLOW":
            faces, tris, poles = target_faces, 0, max(2, target_faces // 100)
        elif method == "VOXEL":
            faces, tris, poles = max(4, int(src.face_count * 2)), 0, 4
        elif method == "DECIMATE":
            faces = max(4, int(src.face_count * decimate_ratio))
            tris, poles = faces, src.pole_count
        else:
            raise ValueError(f"Unsupported retopology method: {method}")

        final_name = new_name or f"{object_name}_retopo"
        existing = {o.name for o in self._objects}
        suffix = 0
        candidate = final_name
        while candidate in existing:  # Blender-style .001 collision suffix
            suffix += 1
            candidate = f"{final_name}.{suffix:03d}"

        copy = FakeObject(name=candidate, type_="MESH", location=list(src.location),
                          face_count=faces, tri_count=tris, pole_count=poles)
        self._objects.append(copy)

        if hide_original:
            src.hidden = True

        return {
            "new_name": copy.name,
            "method": method,
            "before": before,
            "after": self._fake_topology(copy),
        }
    

    # ---------------------------------------------------------
    # Lights + World
    # ---------------------------------------------------------
    def create_light(self, name, light_type="POINT", location=None, rotation=None,
                     color=None, energy=1000.0, size=0.25, spot_angle=45.0):
        existing = {o.name for o in self._objects}
        final_name, suffix = name, 0
        while final_name in existing:  # Blender-style .001 collision suffix
            suffix += 1
            final_name = f"{name}.{suffix:03d}"

        obj = FakeObject(name=final_name, type_="LIGHT",
                         location=list(location) if location else [0.0, 0.0, 3.0],
                         rotation=list(rotation) if rotation else [0.0, 0.0, 0.0])
        obj.light_type = light_type
        obj.light_color = list(color) if color else [1.0, 1.0, 1.0]
        obj.light_energy = energy
        obj.light_size = size
        obj.spot_angle = spot_angle
        self._objects.append(obj)
        return obj

    def set_world(self, color=None, strength=None):
        if color is not None:
            self.world["color"] = list(color)[:3]
        if strength is not None:
            self.world["strength"] = float(strength)
        return dict(self.world)

    # ---------------------------------------------------------
    # Animation — Step 9.13
    # ---------------------------------------------------------
    def insert_keyframe(self, object_name, frame, location=None):
        obj = self.get_object(object_name)
        if obj is None:
            return False

        if location is not None:
            obj.location = location

        obj.keyframes.append((frame, list(obj.location)))
        return True

    def get_keyframes(self, object_name):
        obj = self.get_object(object_name)
        if obj is None:
            return []
        return sorted(frame for frame, _ in obj.keyframes)