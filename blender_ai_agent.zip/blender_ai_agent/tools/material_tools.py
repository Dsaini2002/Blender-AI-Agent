"""Material Tools"""

from .base import Permission, Tool, ToolResult
from .models import AssignMaterialInput, CreateMaterialInput, ModifyMaterialInput


class CreateMaterialTool(Tool):
    name = "material.create"
    auto_name = "Material"
    description = "Creates a new material, optionally with a base color."
    permission = Permission.SAFE_WRITE
    input_model = CreateMaterialInput

    def __init__(self, bridge):
        self._bridge = bridge

    def run(self, validated_input: CreateMaterialInput) -> ToolResult:
        material = self._bridge.create_material(
            name=validated_input.name,
            color=validated_input.color,
        )
        return ToolResult.ok({"name": material.name})


class AssignMaterialTool(Tool):
    name = "material.assign"
    description = "Assigns an existing material to an existing object."
    permission = Permission.SAFE_WRITE
    input_model = AssignMaterialInput

    def __init__(self, bridge):
        self._bridge = bridge

    def run(self, validated_input: AssignMaterialInput) -> ToolResult:
        assigned = self._bridge.assign_material(
            object_name=validated_input.object_name,
            material_name=validated_input.material_name,
        )

        if not assigned:
            return ToolResult.fail(
                f"Could not assign '{validated_input.material_name}' to "
                f"'{validated_input.object_name}' — object or material not found."
            )

        return ToolResult.ok({
            "object": validated_input.object_name,
            "material": validated_input.material_name,
        })


class ModifyMaterialTool(Tool):
    name = "material.modify"
    description = (
        "Updates color, roughness, metallic, and/or emission on an existing material. "
        "Set emission_color (+ emission_strength, e.g. 3-10) to make an object GLOW like a "
        "campfire flame, the moon, a lamp or a neon sign. Emissive objects light up in the "
        "render but do not by themselves cast light on neighbours - pair with light.create "
        "for that."
    )
    permission = Permission.SAFE_WRITE
    input_model = ModifyMaterialInput

    def __init__(self, bridge):
        self._bridge = bridge

    def run(self, validated_input: ModifyMaterialInput) -> ToolResult:
        material = self._bridge.modify_material(
            name=validated_input.name,
            color=validated_input.color,
            roughness=validated_input.roughness,
            metallic=validated_input.metallic,
            emission_color=validated_input.emission_color,
            emission_strength=validated_input.emission_strength,
        )

        if material is None:
            return ToolResult.fail(f"Material '{validated_input.name}' not found.")

        return ToolResult.ok({"name": material.name})