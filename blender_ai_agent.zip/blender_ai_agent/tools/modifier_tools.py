"""Modifier Tools"""

from .base import Permission, Tool, ToolResult
from .models import AddModifierInput, ConfigureModifierInput, RemoveModifierInput


class AddModifierTool(Tool):
    name = "modifier.add"
    description = (
        "Adds a new modifier to an existing object. modifier_type accepts ANY Blender "
        "modifier type string, not just Bevel - e.g. BEVEL (rounded edges), "
        "SUBSURF (smooth subdivision), SOLIDIFY (give a flat plane real thickness), "
        "MIRROR (symmetric geometry - model half a car/character and mirror it), "
        "BOOLEAN (cut/join/intersect one object's shape with another - use for vents, "
        "grilles, windows, panel gaps), ARRAY (repeat an object in a line/grid, e.g. slats, spokes)."
    )
    permission = Permission.SAFE_WRITE
    input_model = AddModifierInput

    def __init__(self, bridge):
        self._bridge = bridge

    def run(self, validated_input: AddModifierInput) -> ToolResult:
        modifier = self._bridge.add_modifier(
            object_name=validated_input.object_name,
            modifier_name=validated_input.modifier_name,
            modifier_type=validated_input.modifier_type,
        )

        if modifier is None:
            return ToolResult.fail(f"Object '{validated_input.object_name}' not found.")

        return ToolResult.ok({
            "object": validated_input.object_name,
            "modifier": modifier.name,
            "type": modifier.type,
        })


class RemoveModifierTool(Tool):
    name = "modifier.remove"
    description = "Removes a modifier from an existing object."
    permission = Permission.DESTRUCTIVE  # modifier configuration lost ho jaayegi
    input_model = RemoveModifierInput

    def __init__(self, bridge):
        self._bridge = bridge

    def run(self, validated_input: RemoveModifierInput) -> ToolResult:
        removed = self._bridge.remove_modifier(
            object_name=validated_input.object_name,
            modifier_name=validated_input.modifier_name,
        )

        if not removed:
            return ToolResult.fail(
                f"Could not remove modifier '{validated_input.modifier_name}' from "
                f"'{validated_input.object_name}' — object or modifier not found."
            )

        return ToolResult.ok({
            "object": validated_input.object_name,
            "removed": validated_input.modifier_name,
        })


class ConfigureModifierTool(Tool):
    name = "modifier.configure"
    description = (
        "Updates properties of an existing modifier via a properties dict, e.g. "
        "{\"width\": 0.03, \"segments\": 3} for Bevel, {\"levels\": 2} for Subdivision, "
        "{\"thickness\": 0.05} for Solidify, {\"use_axis\": [true, false, false]} for Mirror. "
        "For BOOLEAN's 'object' property or MIRROR's 'mirror_object' property, pass the "
        "OTHER object's existing name as a plain string (e.g. {\"object\": \"grille_cutter\", "
        "\"operation\": \"DIFFERENCE\"}) - it will be resolved to that object automatically."
    )
    permission = Permission.SAFE_WRITE
    input_model = ConfigureModifierInput

    def __init__(self, bridge):
        self._bridge = bridge

    def run(self, validated_input: ConfigureModifierInput) -> ToolResult:
        modifier = self._bridge.configure_modifier(
            object_name=validated_input.object_name,
            modifier_name=validated_input.modifier_name,
            properties=validated_input.properties,
        )

        if modifier is None:
            return ToolResult.fail(
                f"Could not configure modifier '{validated_input.modifier_name}' on "
                f"'{validated_input.object_name}' — object or modifier not found."
            )

        return ToolResult.ok({
            "object": validated_input.object_name,
            "modifier": modifier.name,
        })