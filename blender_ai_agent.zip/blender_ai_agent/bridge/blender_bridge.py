"""
BlenderBridge
=============
Hinglish: Ye class Blender ke saare raw `bpy` calls ko encapsulate karti hai.
"""

import bpy


class BlenderBridge:
    """Blender ke saath saara low-level interaction is class ke through hoga."""

    # ---------------------------------------------------------
    # Scene level
    # ---------------------------------------------------------
    def get_scene(self):
        return bpy.context.scene

    def get_scene_name(self) -> str:
        return self.get_scene().name

    # ---------------------------------------------------------
    # Object level — read
    # ---------------------------------------------------------
    def get_objects(self):
        return list(bpy.data.objects)

    def get_object(self, name: str):
        return bpy.data.objects.get(name)

    # ---------------------------------------------------------
    # Object level — write
    # ---------------------------------------------------------
    def create_object(self, name: str, object_type: str = "MESH", primitive: str = "CUBE", location=None):
        """Naya object banata hai. Phase 2 mein `location` bhi accept karta hai."""
        primitive = (primitive or "CUBE").upper()

        if object_type != "MESH":
            raise ValueError(f"Unsupported object_type: {object_type}")

        if primitive == "CUBE":
            bpy.ops.mesh.primitive_cube_add()
        elif primitive == "SPHERE":
            bpy.ops.mesh.primitive_uv_sphere_add()
        elif primitive == "CONE":
            bpy.ops.mesh.primitive_cone_add()
        elif primitive == "CYLINDER":
            bpy.ops.mesh.primitive_cylinder_add()
        elif primitive == "CIRCLE":
            bpy.ops.mesh.primitive_circle_add()
        elif primitive == "PLANE":
            bpy.ops.mesh.primitive_plane_add()
        elif primitive == "TORUS":
            bpy.ops.mesh.primitive_torus_add()
        elif primitive == "MONKEY":
            bpy.ops.mesh.primitive_monkey_add()
        else:
            raise ValueError(f"Unsupported primitive: {primitive}")

        obj = bpy.context.view_layer.objects.active
        obj.name = name

        if location is not None:
            obj.location = location

        return obj

    def delete_object(self, name: str) -> bool:
        obj = self.get_object(name)
        if obj is None:
            return False
        bpy.data.objects.remove(obj, do_unlink=True)
        return True

    def duplicate_object(self, name: str, new_name: str = None):
        obj = self.get_object(name)
        if obj is None:
            return None

        bpy.ops.object.select_all(action='DESELECT')
        obj.select_set(True)
        bpy.context.view_layer.objects.active = obj
        bpy.ops.object.duplicate()

        new_obj = bpy.context.view_layer.objects.active
        if new_name:
            new_obj.name = new_name

        return new_obj

    def rename_object(self, old_name: str, new_name: str):
        obj = self.get_object(old_name)
        if obj is None:
            return None
        obj.name = new_name
        return obj

    def transform_object(self, name: str, location=None, rotation=None, scale=None):
        obj = self.get_object(name)
        if obj is None:
            return None

        if location is not None:
            obj.location = location
        if rotation is not None:
            obj.rotation_euler = rotation
        if scale is not None:
            obj.scale = scale

        return obj

    # ---------------------------------------------------------
    # Material level — Step 2.5
    # ---------------------------------------------------------
    def get_material(self, name: str):
        return bpy.data.materials.get(name)

    def create_material(self, name: str, color=None):
        material = bpy.data.materials.new(name=name)
        material.use_nodes = True

        if color is not None:
            self._set_material_base_color(material, color)

        return material

    def assign_material(self, object_name: str, material_name: str):
        obj = self.get_object(object_name)
        material = self.get_material(material_name)

        if obj is None or material is None:
            return False

        if obj.data.materials:
            obj.data.materials[0] = material
        else:
            obj.data.materials.append(material)

        return True

    def modify_material(self, name: str, color=None, roughness=None, metallic=None):
        material = self.get_material(name)
        if material is None:
            return None

        if color is not None:
            self._set_material_base_color(material, color)

        bsdf = self._get_principled_bsdf(material)
        if bsdf is not None:
            if roughness is not None:
                bsdf.inputs["Roughness"].default_value = roughness
            if metallic is not None:
                bsdf.inputs["Metallic"].default_value = metallic

        return material

    def _get_principled_bsdf(self, material):
        if not material.use_nodes:
            return None
        for node in material.node_tree.nodes:
            if node.type == 'BSDF_PRINCIPLED':
                return node
        return None

    def _set_material_base_color(self, material, color):
        bsdf = self._get_principled_bsdf(material)
        if bsdf is not None:
            rgba = list(color) + [1.0] if len(color) == 3 else list(color)
            bsdf.inputs["Base Color"].default_value = rgba

    # ---------------------------------------------------------
    # Modifier level — Step 2.6
    # ---------------------------------------------------------
    def add_modifier(self, object_name: str, modifier_name: str, modifier_type: str = "BEVEL"):
        obj = self.get_object(object_name)
        if obj is None:
            return None

        modifier = obj.modifiers.new(name=modifier_name, type=modifier_type)
        return modifier

    def remove_modifier(self, object_name: str, modifier_name: str) -> bool:
        obj = self.get_object(object_name)
        if obj is None:
            return False

        modifier = obj.modifiers.get(modifier_name)
        if modifier is None:
            return False

        obj.modifiers.remove(modifier)
        return True

    def configure_modifier(self, object_name: str, modifier_name: str, properties: dict):
        obj = self.get_object(object_name)
        if obj is None:
            return None

        modifier = obj.modifiers.get(modifier_name)
        if modifier is None:
            return None

        for key, value in properties.items():
            if hasattr(modifier, key):
                setattr(modifier, key, value)

        return modifier

    # ---------------------------------------------------------
    # Camera / Render level — Step 2.7
    # ---------------------------------------------------------
    def create_camera(self, name: str, location=None, rotation=None):
        """Naya camera object banata hai scene mein."""
        camera_data = bpy.data.cameras.new(name=f"{name}_data")
        camera_obj = bpy.data.objects.new(name=name, object_data=camera_data)
        bpy.context.collection.objects.link(camera_obj)

        if location is not None:
            camera_obj.location = location
        if rotation is not None:
            camera_obj.rotation_euler = rotation

        return camera_obj

    def set_active_camera(self, name: str) -> bool:
        """Scene ka active/render camera set karta hai."""
        obj = self.get_object(name)
        if obj is None or obj.type != 'CAMERA':
            return False

        self.get_scene().camera = obj
        return True

    def render_preview(self, filepath: str) -> str:
        """
        Current scene ka render leta hai aur diye gaye filepath pe
        save karta hai. Agar path invalid/inaccessible ho (jaise
        root C:\), safe temp folder mein fallback karta hai.
        """
        import os
        import tempfile

        directory = os.path.dirname(filepath)
        if not directory or not os.access(directory if os.path.isdir(directory) else tempfile.gettempdir(), os.W_OK):
            filename = os.path.basename(filepath) or "preview.png"
            filepath = os.path.join(tempfile.gettempdir(), filename)

        scene = self.get_scene()
        scene.render.filepath = filepath
        bpy.ops.render.render(write_still=True)
        return filepath
        # ---------------------------------------------------------
    # Geometry Nodes — Step 9.8
    # ---------------------------------------------------------
    def add_geometry_nodes(self, object_name: str, node_group_name: str):
        """Object pe naya Geometry Nodes modifier add karta hai."""
        obj = self.get_object(object_name)
        if obj is None:
            return None

        node_tree = bpy.data.node_groups.new(name=node_group_name, type='GeometryNodeTree')
        modifier = obj.modifiers.new(name=node_group_name, type='NODES')
        modifier.node_group = node_tree
        return modifier

    def get_geometry_nodes(self, object_name: str, modifier_name: str):
        """Object ke Geometry Nodes modifier ko dhundta hai."""
        obj = self.get_object(object_name)
        if obj is None:
            return None
        return obj.modifiers.get(modifier_name)

    # ---------------------------------------------------------
    # Animation — Step 9.13
    # ---------------------------------------------------------
    def insert_keyframe(self, object_name: str, frame: int, location=None):
        """Object ki current (ya di gayi) location pe keyframe insert karta hai."""
        obj = self.get_object(object_name)
        if obj is None:
            return False

        if location is not None:
            obj.location = location

        obj.keyframe_insert(data_path="location", frame=frame)
        return True

    def get_keyframes(self, object_name: str):
        """Object ke location keyframes ki frame-number list deta hai."""
        obj = self.get_object(object_name)
        if obj is None or obj.animation_data is None or obj.animation_data.action is None:
            return []

        frames = set()
        for fcurve in obj.animation_data.action.fcurves:
            if fcurve.data_path == "location":
                for keyframe_point in fcurve.keyframe_points:
                    frames.add(int(keyframe_point.co[0]))
        return sorted(frames)